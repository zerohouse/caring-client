import {Component, OnInit} from '@angular/core';

@Component({
    selector: 'cr-pay-calculation.',
    templateUrl: './pay-calculation.component.html',
    styleUrls: ['./pay-calculation.component.sass']
})


export class Pay_calculationComponent implements OnInit {
    type = true;
    level: any;

    constructor() {
    }

    ngOnInit() {
    }

}
